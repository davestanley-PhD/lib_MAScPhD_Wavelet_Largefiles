NOTE:

This release of the FTrack package (v0.9.3) contains two main programs (FTrack and FAnalyze), 
their associated Matlab functions, and documentation/user's manuals for both packages.  
FTrack tracks the trajectory of an animal in a video and FAnalyze gives the user the ability to analyze the resulting trajectory.
Please read the documentation carefully before use.

Both FTrack and FAnalyze have been tested on 32-bit Windows XP machines with Matlab v2006a, v2006b, and v2007a.
They have also been tested on a Linux 64-bit machine running Matlab v2007a, HOWEVER,in order for FTrack to properly work on Linux and Mac machines, 
videoIO .mex files will have to be recompiled.  Directions for how to do this are contained within the videoIO folder, 
as well as the licensing agreements for videoIO, which was not written by the author of the FTrack package.
