function [params] = lmax_getConfig()
params = struct('dt',0.005,'tau',4,'DIMM',7,'bb',0.2,'cc',0.03,'mult',5,'angmx1',0.2,'fiduc1',1);
